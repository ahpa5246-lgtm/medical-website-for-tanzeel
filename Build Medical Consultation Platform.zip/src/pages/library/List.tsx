import { useMemo, useState } from "react";
import {
  BookMarked,
  Download,
  FileText,
  LibraryBig,
  Search,
  ShieldCheck,
  BookOpen,
  Users,
  Trophy,
  Check,
  Tag,
} from "lucide-react";
import Badge from "@/components/ui/Badge";
import Button from "@/components/ui/Button";
import { LIBRARY_ITEMS } from "@/data/learning";
import WaveDivider from "@/components/decorative/WaveDivider";
import HeroRings from "@/components/decorative/HeroRings";

const categories = ["الكل", "دليل عملي", "سلامة المريض", "الصحة النفسية", "البحث الطبي"];

const FORMAT_COLORS: Record<string, string> = {
  "PDF":         "bg-emerald-100 text-emerald-800",
  "دليل":        "bg-teal-100 text-teal-800",
  "قائمة عمل":  "bg-green-100 text-green-800",
};

const HERO_STATS = [
  { icon: LibraryBig,  value: "٦",    label: "مرجع متاح" },
  { icon: BookOpen,    value: "+٥٠٠", label: "تنزيل حتى الآن" },
  { icon: ShieldCheck, value: "١٠٠٪", label: "مصادر موثّقة" },
  { icon: Users,       value: "٤",    label: "متخصص مساهم" },
];

export default function LibraryList() {
  const [query, setQuery]           = useState("");
  const [category, setCategory]     = useState("الكل");
  const [downloaded, setDownloaded] = useState<Set<string>>(new Set());

  const items = useMemo(
    () =>
      LIBRARY_ITEMS.filter(
        (item) =>
          (category === "الكل" || item.category === category) &&
          `${item.title} ${item.author} ${item.category}`.includes(query),
      ),
    [category, query],
  );

  function toggleDownload(id: string) {
    setDownloaded((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  }

  return (
    <div dir="rtl" className="learning-page min-h-screen">

      {/* ── Hero ───────────────────────────────────────────── */}
      <section className="edu-hero">
        <div className="edu-hero-orb" aria-hidden />
        <HeroRings className="-left-16 top-[-6rem] z-0 h-[24rem] w-[24rem] opacity-70 sm:h-[30rem] sm:w-[30rem]" stroke="#d9f3e5" />

        <div className="relative mx-auto max-w-6xl px-4 sm:px-6">
          {/* Kicker */}
          <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-3.5 py-1.5 text-xs font-bold text-white backdrop-blur-sm">
            <LibraryBig className="h-4 w-4 text-emerald-300" />
            المكتبة الطبية
          </div>

          {/* Heading */}
          <div className="mb-8 max-w-2xl">
            <h1 className="text-4xl font-black leading-[1.18] tracking-tight text-white sm:text-5xl">
              معرفتك الطبية{" "}
              <span className="text-emerald-300">تستحق مرجعًا حيًا.</span>
            </h1>
            <p className="mt-4 text-base leading-8 text-emerald-100/90">
              أدلة مختارة، أدوات عملية، ومراجع واضحة المصدر — لتعود إليها في اللحظة التي تحتاجها.
            </p>
          </div>

          {/* CTA row */}
          <div className="mb-12 flex flex-wrap items-center gap-3">
            <a
              href="#library"
              className="inline-flex items-center gap-2 rounded-xl bg-emerald-400 px-5 py-3 text-sm font-black text-emerald-950 shadow-[0_8px_24px_rgba(52,211,153,.35)] transition hover:bg-emerald-300"
            >
              <BookOpen className="h-4 w-4" />
              ادخل المكتبة
            </a>
            <span className="inline-flex items-center gap-2 rounded-xl border border-white/20 bg-white/10 px-4 py-3 text-xs font-bold text-white/90">
              <ShieldCheck className="h-4 w-4" />
              مصدر واضح لكل مادة
            </span>
          </div>

          {/* Stats row */}
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            {HERO_STATS.map(({ icon: Icon, value, label }) => (
              <div
                key={label}
                className="flex items-center gap-3 rounded-2xl border border-white/15 bg-white/10 px-4 py-3.5 backdrop-blur-sm"
              >
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-emerald-500/25">
                  <Icon className="h-4.5 w-4.5 text-emerald-300" />
                </div>
                <div>
                  <p className="text-lg font-black text-white leading-none">{value}</p>
                  <p className="mt-0.5 text-[11px] text-emerald-200">{label}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
        <WaveDivider color="#ffffff" />
      </section>

      {/* ── Filters ────────────────────────────────────────── */}
      <section id="library" className="border-b border-emerald-100 bg-white px-4 py-5 shadow-sm sm:px-6">
        <div className="mx-auto max-w-6xl space-y-4">
          {/* Search */}
          <div className="relative max-w-xl">
            <Search className="pointer-events-none absolute inset-y-0 start-0 my-auto ms-3.5 h-4 w-4 text-slate-400" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="ابحث في المكتبة…"
              className="w-full rounded-xl border border-slate-200 bg-slate-50 py-3 pe-4 ps-10 text-sm text-slate-800 outline-none placeholder:text-slate-400 focus:border-emerald-400 focus:bg-white focus:ring-2 focus:ring-emerald-100"
            />
          </div>

          {/* Category pills */}
          <div className="flex gap-2 overflow-x-auto">
            {categories.map((item) => (
              <button
                key={item}
                onClick={() => setCategory(item)}
                className={`shrink-0 rounded-xl px-4 py-2 text-xs font-bold transition ${
                  category === item
                    ? "bg-emerald-600 text-white shadow-sm"
                    : "border border-slate-200 bg-white text-slate-600 hover:border-emerald-300 hover:text-emerald-700"
                }`}
              >
                {item}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* ── Library grid ───────────────────────────────────── */}
      <section className="mx-auto max-w-6xl px-4 py-10 sm:px-6">
        {items.length === 0 ? (
          <div className="py-24 text-center">
            <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-emerald-50">
              <BookOpen className="h-7 w-7 text-emerald-400" />
            </div>
            <p className="font-semibold text-slate-600">لم نجد مرجعًا بهذه المواصفات.</p>
            <button
              onClick={() => { setQuery(""); setCategory("الكل"); }}
              className="mt-2 text-sm text-emerald-600 underline"
            >
              مسح الفلاتر
            </button>
          </div>
        ) : (
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {items.map((item) => (
              <article key={item.id} className="library-card group flex flex-col">

                {/* Cover image */}
                <div className="relative h-44 overflow-hidden">
                  <img
                    src={item.image}
                    alt={`غلاف ${item.title}`}
                    className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-emerald-950/60 to-transparent" />

                  {/* Format badge */}
                  <div className="absolute bottom-3 end-3">
                    <span className={`rounded-lg px-2.5 py-1 text-[11px] font-bold ${FORMAT_COLORS[item.format] ?? "bg-white/90 text-slate-700"}`}>
                      {item.format}
                    </span>
                  </div>

                  {/* File icon overlay */}
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 transition-opacity duration-300 group-hover:opacity-100">
                    <div className="flex h-12 w-12 items-center justify-center rounded-full bg-white/90 shadow-lg">
                      <FileText className="h-6 w-6 text-emerald-700" />
                    </div>
                  </div>
                </div>

                {/* Card body */}
                <div className="flex flex-1 flex-col p-5">
                  {/* Category + pages */}
                  <div className="mb-3 flex items-center justify-between gap-2">
                    <span className="inline-flex items-center gap-1 rounded-full border border-emerald-200 bg-emerald-50 px-2.5 py-1 text-[11px] font-bold text-emerald-700">
                      <Tag className="h-3 w-3" />
                      {item.category}
                    </span>
                    <span className="text-xs text-slate-400">{item.pages}</span>
                  </div>

                  <h2 className="text-base font-black leading-tight text-slate-900 group-hover:text-emerald-800">
                    {item.title}
                  </h2>
                  <p className="mt-2 line-clamp-2 flex-1 text-xs leading-6 text-slate-500">
                    {item.description}
                  </p>

                  {/* Footer */}
                  <div className="mt-4 flex items-center justify-between border-t border-slate-100 pt-4">
                    <span className="text-xs text-slate-400">{item.author}</span>
                    <button
                      onClick={() => toggleDownload(item.id)}
                      className={`flex items-center gap-1.5 rounded-xl px-4 py-2 text-xs font-bold transition ${
                        downloaded.has(item.id)
                          ? "bg-emerald-50 text-emerald-700 ring-1 ring-emerald-200"
                          : "bg-emerald-600 text-white shadow-sm hover:bg-emerald-700"
                      }`}
                    >
                      {downloaded.has(item.id)
                        ? <><Check className="h-3.5 w-3.5" /> أُضيف</>
                        : <><Download className="h-3.5 w-3.5" /> تنزيل</>}
                    </button>
                  </div>
                </div>
              </article>
            ))}
          </div>
        )}

        {/* ── Usage disclaimer ───────────────────────────── */}
        <div className="mt-12 flex gap-3 rounded-2xl border border-emerald-200 bg-emerald-50/80 p-5 text-sm leading-7 text-emerald-900">
          <BookMarked className="mt-0.5 h-5 w-5 shrink-0 text-emerald-600" />
          <p>
            <strong>تنبيه الاستخدام:</strong>{" "}
            المواد التعليمية لا تُغني عن التدريب السريري أو المرجع المعتمد في مؤسستك، ويجب الاستشهاد بالمصدر ورخصة الاستخدام قبل إعادة النشر.
          </p>
        </div>
      </section>
    </div>
  );
}
