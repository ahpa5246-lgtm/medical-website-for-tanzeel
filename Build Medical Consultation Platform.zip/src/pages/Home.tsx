import { useState, type ReactNode } from "react";
import { Link, useNavigate } from "react-router-dom";
import {
  Activity,
  Baby,
  Brain,
  ChevronLeft,
  HeartPulse,
  LockKeyhole,
  MessageCircle,
  Microscope,
  Search,
  ShieldCheck,
  Stethoscope,
  UserRoundCheck,
  BookOpen,
  Syringe,
  ArrowLeft,
} from "lucide-react";
import Button from "@/components/ui/Button";
import Badge from "@/components/ui/Badge";
import { SPECIALTIES } from "@/data/specialties";
import { MOCK_ARTICLES, STATS } from "@/data/mockData";
import FingerprintRidges from "@/components/decorative/FingerprintRidges";
import WaveDivider from "@/components/decorative/WaveDivider";

const FEATURED_SPECIALTIES = SPECIALTIES.slice(0, 8);
const specialtyIcons: ReactNode[] = [
  <Stethoscope />, <Microscope />, <Brain />, <Activity />,
  <MessageCircle />, <Baby />, <HeartPulse />, <Syringe />,
];

const STATS_TILES = [
  { value: "٢٤/٧", label: "دعم متواصل", variant: "stat-tile-primary" },
  { value: `+${STATS.verifiedDoctors}`, label: "طبيب معتمد", variant: "stat-tile-dark" },
  { value: `+${(STATS.consultationsAnswered / 1000).toFixed(0)}K`, label: "استشارة أُجيبت", variant: "stat-tile-primary" },
  { value: `${STATS.specialties}`, label: "تخصص طبي", variant: "stat-tile-dark" },
];

export default function Home() {
  const [searchQuery, setSearchQuery] = useState("");
  const navigate = useNavigate();

  function handleSearch(event: React.FormEvent) {
    event.preventDefault();
    navigate(`/consultations/new${searchQuery.trim() ? `?q=${encodeURIComponent(searchQuery)}` : ""}`);
  }

  return (
    <div dir="rtl" className="overflow-x-hidden bg-white">

      {/* ── Hero ────────────────────────────────────────────── */}
      <section className="hero-canvas relative isolate overflow-hidden pt-12 pb-10 sm:pt-16 sm:pb-14 lg:pt-20">
        <div className="relative z-[1] mx-auto max-w-6xl px-4 sm:px-6">
          <div className="grid items-end gap-8 lg:grid-cols-[1.1fr_0.9fr] lg:gap-10">

            {/* Text column */}
            <div className="pb-12 text-center lg:text-right lg:pb-16">
              <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-primary-100 bg-primary-50 px-3.5 py-1.5 text-xs font-bold text-primary-700">
                <span className="relative flex h-2 w-2">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
                  <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-500" />
                </span>
                أطباء موثّقون جاهزون للإجابة
              </div>

              <h1 className="max-w-xl text-[2.7rem] font-black leading-[1.18] tracking-[-0.04em] text-slate-900 sm:text-5xl lg:text-[3.5rem] lg:mx-0">
                نساعدك على اتخاذ{" "}
                <span className="relative whitespace-nowrap">
                  <span className="relative z-10 text-primary-600">قرار صحي</span>
                  <svg
                    className="swirl-accent"
                    style={{ position: "absolute", bottom: "-0.3em", left: 0, right: 0, width: "100%", height: "0.45em" }}
                    viewBox="0 0 200 18"
                    preserveAspectRatio="none"
                    aria-hidden
                  >
                    <path d="M4 14 C50 4, 100 18, 150 6 C170 2, 185 10, 196 5" />
                  </svg>
                </span>{" "}
                أفضل
              </h1>

              <p className="mx-auto mt-6 max-w-lg text-base leading-8 text-slate-500 lg:mx-0">
                اطرح استشارتك لطبيب معتمد في تخصصه، واحصل على إجابة طبية موثوقة — بخصوصية تامة وبدون انتظار.
              </p>

              <form onSubmit={handleSearch} className="mx-auto mt-8 max-w-lg lg:mx-0">
                <div className="flex gap-2 rounded-2xl border border-slate-200 bg-white p-2 shadow-[0_8px_30px_rgba(11,110,142,.10)]">
                  <div className="relative flex-1">
                    <Search className="pointer-events-none absolute inset-y-0 start-0 my-auto ms-3.5 h-4.5 w-4.5 text-slate-400" />
                    <input
                      type="text"
                      placeholder="ما الذي تودّ الاستفسار عنه؟"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full rounded-xl border-none bg-transparent py-3 pe-3 ps-10 text-sm text-slate-800 outline-none placeholder:text-slate-400"
                    />
                  </div>
                  <Button size="md" type="submit" className="shrink-0 rounded-xl px-5 text-sm shadow-none">
                    ابدأ استشارة
                  </Button>
                </div>
              </form>

              <div className="mt-5 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-xs font-medium text-slate-500 lg:justify-start">
                <span className="inline-flex items-center gap-1.5">
                  <ShieldCheck className="h-3.5 w-3.5 text-primary-500" /> تحقق مهني موثّق
                </span>
                <span className="inline-flex items-center gap-1.5">
                  <LockKeyhole className="h-3.5 w-3.5 text-primary-500" /> خصوصية محمية
                </span>
                <span className="inline-flex items-center gap-1.5">
                  <HeartPulse className="h-3.5 w-3.5 text-coral-500" /> ليست لحالات الطوارئ
                </span>
              </div>
            </div>

            {/* Doctor photo column */}
            <div className="relative mx-auto w-full max-w-sm lg:max-w-none">
              {/* Decorative swirl top-right */}
              <svg
                className="swirl-accent"
                style={{ position: "absolute", top: "8%", left: "-5%", width: "4.5rem", height: "4.5rem", zIndex: 10 }}
                viewBox="0 0 60 60"
                aria-hidden
              >
                <path d="M10 30 C10 10, 30 5, 40 20 C50 35, 40 52, 22 48 C10 44, 8 34, 18 28" />
              </svg>
              {/* Decorative dots */}
              <svg
                className="absolute bottom-[18%] left-[-8%] z-10 opacity-50"
                width="52" height="52" viewBox="0 0 52 52" aria-hidden
              >
                {[0,1,2,3].map(row =>
                  [0,1,2,3].map(col => (
                    <circle key={`${row}-${col}`} cx={6 + col * 14} cy={6 + row * 14} r="2.5" fill="#e8603c" />
                  ))
                )}
              </svg>

              <FingerprintRidges className="-right-16 top-2 z-0 h-[24rem] w-[24rem] sm:h-[30rem] sm:w-[30rem]" />

              <div className="doctor-blob-wrap min-h-[340px] sm:min-h-[400px] lg:min-h-[460px]">
                <img
                  src="https://images.unsplash.com/photo-1758691463582-11aea602cd4a?w=560&h=680&fit=crop&auto=format&crop=top"
                  alt="طبيب متخصص معتمد"
                  className="doctor-img"
                />
              </div>

              {/* Floating badge */}
              <div className="absolute bottom-8 start-0 z-20 flex items-center gap-2.5 rounded-2xl border border-white/80 bg-white px-4 py-2.5 shadow-[0_10px_28px_rgba(11,74,95,.18)]">
                <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary-600 text-white">
                  <UserRoundCheck className="h-4.5 w-4.5" />
                </div>
                <div>
                  <p className="text-[11px] font-bold text-slate-800">أطباء موثّقون</p>
                  <p className="text-[10px] text-slate-500">+{STATS.verifiedDoctors} طبيب معتمد</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <WaveDivider color="#ffffff" />
      </section>

      {/* ── Stats tiles ─────────────────────────────────────── */}
      <section className="bg-white px-4 pb-4 pt-0 sm:px-6">
        <div className="mx-auto max-w-6xl">
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            {STATS_TILES.map((tile) => (
              <div key={tile.label} className={`stat-tile ${tile.variant}`}>
                <span className="stat-num">{tile.value}</span>
                <span className="stat-label">{tile.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Specialties ─────────────────────────────────────── */}
      <section className="bg-slate-50 py-20 sm:py-24 relative overflow-hidden">
        <FingerprintRidges className="-right-20 -top-16 z-0 h-[22rem] w-[22rem] opacity-35" />
        <div className="mx-auto max-w-6xl px-4 sm:px-6">
          <div className="mb-10 flex items-end justify-between gap-5">
            <div>
              <p className="section-kicker">تخصصاتنا الطبية</p>
              <h2 className="mt-2 text-3xl font-black tracking-tight text-slate-900">
                ابدأ من المكان الصحيح
              </h2>
            </div>
            <Link to="/doctors" className="hidden items-center gap-1 text-sm font-bold text-primary-700 hover:text-primary-900 sm:flex">
              دليل الأطباء <ChevronLeft className="h-4 w-4 rtl-flip" />
            </Link>
          </div>

          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            {FEATURED_SPECIALTIES.map((specialty, index) => (
              <Link
                key={specialty.id}
                to={`/consultations/new?specialty=${specialty.id}`}
                className="specialty-card group"
              >
                <span className="specialty-icon">{specialtyIcons[index]}</span>
                <span className="mt-auto block pt-5 text-sm font-extrabold leading-6 text-slate-800 group-hover:text-primary-700">
                  {specialty.nameAr}
                </span>
                <span className="mt-1 block text-xs text-slate-400">استشارة موثّقة</span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ── Trust section ───────────────────────────────────── */}
      <section className="bg-white py-20 sm:py-24">
        <div className="mx-auto max-w-6xl px-4 sm:px-6">
          <div className="grid gap-10 lg:grid-cols-[0.88fr_1.12fr] lg:items-center lg:gap-16">
            <div>
              <p className="section-kicker">لماذا ميدكونكت؟</p>
              <h2 className="mt-3 text-3xl font-black leading-tight tracking-tight text-slate-900">
                الثقة ليست خيارًا — <span className="text-primary-600">هي الأساس.</span>
              </h2>
              <p className="mt-5 text-sm leading-8 text-slate-500">
                نراجع هويات الأطباء وشهاداتهم قبل تفعيل أي حساب. لا تُعرض على المريض أي إجابات مولّدة بالذكاء الاصطناعي باعتبارها رأيًا طبيًا.
              </p>
              <Link
                to="/legal/disclaimer"
                className="mt-7 inline-flex items-center gap-2 rounded-xl border border-primary-200 bg-primary-50 px-4 py-2.5 text-sm font-bold text-primary-700 transition hover:bg-primary-100"
              >
                اقرأ التنويه الطبي الكامل <ArrowLeft className="h-4 w-4 rtl-flip" />
              </Link>
            </div>

            <div className="grid gap-3 sm:grid-cols-3">
              {[
                { icon: ShieldCheck, title: "هوية موثّقة", copy: "كل طبيب يمر بمراجعة مهنية دقيقة قبل نشر ملفه.", color: "text-primary-600", bg: "bg-primary-50" },
                { icon: LockKeyhole, title: "خصوصية أولًا", copy: "استشارتك في مساحة خاصة لا يطّلع عليها غيرك.", color: "text-slate-700", bg: "bg-slate-50" },
                { icon: HeartPulse, title: "سلامتك أولوية", copy: "كشف فوري للأعراض الخطرة مع توجيه لأقرب طوارئ.", color: "text-coral-600", bg: "bg-coral-50" },
              ].map(({ icon: Icon, title, copy, color, bg }) => (
                <div key={title} className="trust-card">
                  <div className={`flex h-11 w-11 items-center justify-center rounded-xl ${bg}`}>
                    <Icon className={`h-5 w-5 ${color}`} />
                  </div>
                  <h3 className="mt-5 text-sm font-extrabold text-slate-800">{title}</h3>
                  <p className="mt-2 text-xs leading-6 text-slate-500">{copy}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ── How it works ────────────────────────────────────── */}
      <section className="bg-slate-50 py-20 sm:py-24">
        <div className="mx-auto max-w-6xl px-4 sm:px-6">
          <div className="mb-10 text-center">
            <p className="section-kicker">خطوات بسيطة</p>
            <h2 className="mt-2 text-3xl font-black tracking-tight text-slate-900">كيف تعمل المنصة؟</h2>
          </div>
          <div className="grid gap-4 sm:grid-cols-3">
            {[
              { step: "١", icon: MessageCircle, title: "شارك استشارتك", copy: "اكتب ما تودّ الاستفسار عنه مع اختيار التخصص المناسب — يمكنك إبقاء هويتك مجهولة." },
              { step: "٢", icon: UserRoundCheck, title: "يصلك طبيب موثّق", copy: "تُوجَّه استشارتك تلقائيًا لطبيب معتمد في التخصص ذاته ليتولى الإجابة." },
              { step: "٣", icon: BookOpen, title: "تابع الحوار", copy: "ناقش التفاصيل مع طبيبك في خيط خاص وآمن، وقيّم الإجابة بعد إغلاق الاستشارة." },
            ].map(({ step, icon: Icon, title, copy }) => (
              <div key={step} className="relative rounded-2xl border-1.5 border-slate-200 bg-white p-6 text-center shadow-sm">
                <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-primary-600 text-white shadow-md shadow-primary-600/25">
                  <Icon className="h-5 w-5" />
                </div>
                <div className="absolute -top-3 start-1/2 -translate-x-1/2 flex h-6 w-6 items-center justify-center rounded-full bg-white border border-slate-200 text-[11px] font-black text-primary-600">
                  {step}
                </div>
                <h3 className="text-sm font-extrabold text-slate-800">{title}</h3>
                <p className="mt-2 text-xs leading-6 text-slate-500">{copy}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Articles ────────────────────────────────────────── */}
      <section className="bg-white py-20 sm:py-24">
        <div className="mx-auto max-w-6xl px-4 sm:px-6">
          <div className="mb-10 flex items-end justify-between">
            <div>
              <p className="section-kicker">مقالات صحية</p>
              <h2 className="mt-2 text-3xl font-black tracking-tight text-slate-900">معرفة صُمّمت لتُفهم</h2>
            </div>
            <Link to="/articles" className="hidden items-center gap-1 text-sm font-bold text-primary-700 hover:text-primary-900 sm:flex">
              كل المقالات <ChevronLeft className="h-4 w-4 rtl-flip" />
            </Link>
          </div>

          <div className="grid gap-4 md:grid-cols-3">
            {MOCK_ARTICLES.slice(0, 3).map((article) => (
              <article key={article.id} className="article-card group">
                <div className="relative h-44 overflow-hidden bg-primary-50">
                  <img
                    src={article.coverUrl}
                    alt={article.title}
                    className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
                  />
                </div>
                <div className="flex flex-1 flex-col p-5">
                  <Badge variant="primary" className="self-start">{article.category}</Badge>
                  <h3 className="mt-3 line-clamp-2 flex-1 text-base font-extrabold leading-7 text-slate-800">
                    {article.title}
                  </h3>
                  <p className="mt-3 text-xs text-slate-400">
                    بقلم {article.authorName} · {article.readTimeMinutes} دقائق
                  </p>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA banner ──────────────────────────────────────── */}
      <section className="bg-slate-50 py-16 sm:py-20 px-4 sm:px-6">
        <div className="mx-auto max-w-3xl rounded-3xl bg-primary-700 px-8 py-12 text-center text-white shadow-[0_20px_60px_rgba(11,74,95,.30)]">
          <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-white/15">
            <Stethoscope className="h-7 w-7" />
          </div>
          <h2 className="text-2xl font-black tracking-tight sm:text-3xl">
            هل لديك سؤال طبي؟
          </h2>
          <p className="mt-3 text-sm leading-7 text-primary-100 max-w-md mx-auto">
            ابدأ استشارتك المجانية الآن وتواصل مع طبيب معتمد في تخصصك — الخدمة مجانية وخصوصيتك مصانة.
          </p>
          <div className="mt-7 flex flex-wrap items-center justify-center gap-3">
            <Link to="/consultations/new">
              <Button
                size="lg"
                className="rounded-xl bg-white text-primary-700 hover:bg-primary-50 shadow-lg shadow-primary-900/20"
              >
                ابدأ استشارتك المجانية
              </Button>
            </Link>
            <Link to="/doctors">
              <Button
                variant="ghost"
                size="lg"
                className="rounded-xl text-white hover:bg-white/10"
              >
                تصفّح الأطباء
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* ── Emergency note ──────────────────────────────────── */}
      <section className="bg-white px-4 pb-14 sm:px-6">
        <div className="emergency-note mx-auto flex max-w-6xl items-start gap-3 p-5 text-sm leading-7">
          <HeartPulse className="mt-0.5 h-5 w-5 shrink-0 text-coral-600" />
          <p>
            <strong>إذا كانت لديك أعراض قد تهدد الحياة، فلا تنتظر استشارة عبر المنصة.</strong>{" "}
            اتصل بالإسعاف أو اذهب إلى أقرب قسم طوارئ فورًا.
          </p>
        </div>
      </section>
    </div>
  );
}
