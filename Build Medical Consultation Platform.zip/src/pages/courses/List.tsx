import { useMemo, useState } from "react";
import {
  BookOpenCheck,
  Check,
  Clock3,
  GraduationCap,
  PlayCircle,
  Search,
  UserRoundCheck,
  Star,
  Users,
  Trophy,
  Zap,
} from "lucide-react";
import Button from "@/components/ui/Button";
import Badge from "@/components/ui/Badge";
import { COURSES } from "@/data/learning";
import WaveDivider from "@/components/decorative/WaveDivider";
import HeroRings from "@/components/decorative/HeroRings";

const levels = ["الكل", "مبتدئ", "متوسط", "متقدم"];

const LEVEL_COLORS: Record<string, string> = {
  "مبتدئ":  "bg-emerald-100 text-emerald-800",
  "متوسط":  "bg-teal-100 text-teal-800",
  "متقدم":  "bg-green-100 text-green-800",
};

const HERO_STATS = [
  { icon: GraduationCap, value: "+٢٠٠٠", label: "متعلم مسجّل" },
  { icon: BookOpenCheck,  value: "٦",    label: "دورة متاحة" },
  { icon: Users,          value: "٦",    label: "مدرّب معتمد" },
  { icon: Trophy,         value: "٩٤٪",  label: "معدل إتمام" },
];

export default function CourseList() {
  const [query, setQuery]       = useState("");
  const [level, setLevel]       = useState("الكل");
  const [enrolled, setEnrolled] = useState<Set<string>>(new Set());

  const visibleCourses = useMemo(
    () =>
      COURSES.filter(
        (c) =>
          (level === "الكل" || c.level === level) &&
          `${c.title} ${c.specialty} ${c.instructor}`.includes(query),
      ),
    [level, query],
  );

  function toggleEnroll(id: string) {
    setEnrolled((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  }

  return (
    <div dir="rtl" className="learning-page min-h-screen">

      {/* ── Hero ───────────────────────────────────────────── */}
      <section className="edu-hero">
        <div className="edu-hero-orb" aria-hidden />
        <HeroRings className="-left-16 top-[-6rem] z-0 h-[24rem] w-[24rem] opacity-70 sm:h-[30rem] sm:w-[30rem]" stroke="#d9f3e5" />

        <div className="relative mx-auto max-w-6xl px-4 sm:px-6">
          {/* Kicker */}
          <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-3.5 py-1.5 text-xs font-bold text-white backdrop-blur-sm">
            <GraduationCap className="h-4 w-4 text-emerald-300" />
            أكاديمية ميدكونكت
          </div>

          {/* Heading + sub */}
          <div className="mb-8 max-w-2xl">
            <h1 className="text-4xl font-black leading-[1.18] tracking-tight text-white sm:text-5xl">
              تعلّم طبي يبني{" "}
              <span className="text-emerald-300">ثقتك بنفسك.</span>
            </h1>
            <p className="mt-4 text-base leading-8 text-emerald-100/90">
              مسارات مُختارة ومراجَعة طبيًا — لطلبة الطب والممارسين على حدٍّ سواء. تعلّم وفق وتيرتك.
            </p>
          </div>

          {/* CTA row */}
          <div className="mb-12 flex flex-wrap items-center gap-3">
            <a
              href="#courses"
              className="inline-flex items-center gap-2 rounded-xl bg-emerald-400 px-5 py-3 text-sm font-black text-emerald-950 shadow-[0_8px_24px_rgba(52,211,153,.35)] transition hover:bg-emerald-300"
            >
              <Zap className="h-4 w-4" />
              استكشف الدورات
            </a>
            <span className="inline-flex items-center gap-2 rounded-xl border border-white/20 bg-white/10 px-4 py-3 text-xs font-bold text-white/90">
              <BookOpenCheck className="h-4 w-4" />
              تعلّم وفق وتيرتك
            </span>
          </div>

          {/* Stats row */}
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            {HERO_STATS.map(({ icon: Icon, value, label }) => (
              <div
                key={label}
                className="flex items-center gap-3 rounded-2xl border border-white/15 bg-white/10 px-4 py-3.5 backdrop-blur-sm"
              >
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-emerald-500/25">
                  <Icon className="h-4.5 w-4.5 text-emerald-300" />
                </div>
                <div>
                  <p className="text-lg font-black text-white leading-none">{value}</p>
                  <p className="mt-0.5 text-[11px] text-emerald-200">{label}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
        <WaveDivider color="#ffffff" />
      </section>

      {/* ── Filters ────────────────────────────────────────── */}
      <section id="courses" className="border-b border-emerald-100 bg-white px-4 py-5 shadow-sm sm:px-6">
        <div className="mx-auto flex max-w-6xl flex-col gap-3 sm:flex-row sm:items-center">
          {/* Search */}
          <div className="relative flex-1">
            <Search className="pointer-events-none absolute inset-y-0 start-0 my-auto ms-3.5 h-4 w-4 text-slate-400" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="ابحث عن دورة أو تخصص أو مدرّب…"
              className="w-full rounded-xl border border-slate-200 bg-slate-50 py-3 pe-4 ps-10 text-sm text-slate-800 outline-none placeholder:text-slate-400 focus:border-emerald-400 focus:bg-white focus:ring-2 focus:ring-emerald-100"
            />
          </div>

          {/* Level pills */}
          <div className="flex items-center gap-2 overflow-x-auto">
            {levels.map((item) => (
              <button
                key={item}
                onClick={() => setLevel(item)}
                className={`shrink-0 rounded-xl px-4 py-2 text-xs font-bold transition ${
                  level === item
                    ? "bg-emerald-600 text-white shadow-sm"
                    : "border border-slate-200 bg-white text-slate-600 hover:border-emerald-300 hover:text-emerald-700"
                }`}
              >
                {item}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* ── Course grid ────────────────────────────────────── */}
      <section className="mx-auto max-w-6xl px-4 py-10 sm:px-6">
        {visibleCourses.length === 0 ? (
          <div className="py-24 text-center">
            <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-emerald-50">
              <Search className="h-7 w-7 text-emerald-400" />
            </div>
            <p className="font-semibold text-slate-600">لا توجد دورات تطابق بحثك الآن.</p>
            <button
              onClick={() => { setQuery(""); setLevel("الكل"); }}
              className="mt-2 text-sm text-emerald-600 underline"
            >
              مسح الفلاتر
            </button>
          </div>
        ) : (
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {visibleCourses.map((course) => (
              <article key={course.id} className="course-card group flex flex-col">

                {/* Cover image */}
                <div className="relative h-48 overflow-hidden">
                  <img
                    src={course.image}
                    alt={`صورة دورة ${course.title}`}
                    className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
                  />
                  <div className={`absolute inset-0 bg-gradient-to-t ${course.color} opacity-60`} />

                  {/* Overlay badges */}
                  <div className="absolute inset-x-4 bottom-4 flex items-end justify-between">
                    <span className={`rounded-lg px-2.5 py-1 text-[11px] font-bold ${LEVEL_COLORS[course.level]}`}>
                      {course.level}
                    </span>
                    <span className={`rounded-lg px-2.5 py-1 text-[11px] font-black ${
                      course.isFree
                        ? "bg-emerald-400 text-emerald-950"
                        : "bg-white/90 text-slate-800"
                    }`}>
                      {course.price}
                    </span>
                  </div>

                  {/* Play button overlay */}
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 transition-opacity duration-300 group-hover:opacity-100">
                    <div className="flex h-12 w-12 items-center justify-center rounded-full bg-white/90 shadow-lg">
                      <PlayCircle className="h-6 w-6 text-emerald-700" />
                    </div>
                  </div>
                </div>

                {/* Card body */}
                <div className="flex flex-1 flex-col p-5">
                  <p className="text-xs font-bold text-emerald-700">{course.specialty}</p>
                  <h2 className="mt-2 text-base font-black leading-tight text-slate-900 group-hover:text-emerald-800">
                    {course.title}
                  </h2>
                  <p className="mt-2 line-clamp-2 flex-1 text-xs leading-6 text-slate-500">
                    {course.description}
                  </p>

                  {/* Meta row */}
                  <div className="mt-4 flex flex-wrap gap-x-4 gap-y-1.5 text-xs text-slate-500">
                    <span className="flex items-center gap-1">
                      <UserRoundCheck className="h-3.5 w-3.5 text-emerald-600" />
                      {course.instructor}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock3 className="h-3.5 w-3.5 text-emerald-600" />
                      {course.duration}
                    </span>
                  </div>

                  {/* Footer */}
                  <div className="mt-4 flex items-center justify-between border-t border-slate-100 pt-4">
                    <span className="flex items-center gap-1.5 text-xs font-semibold text-slate-500">
                      <PlayCircle className="h-4 w-4 text-emerald-500" />
                      {course.lessons} درسًا
                    </span>
                    <button
                      onClick={() => toggleEnroll(course.id)}
                      className={`flex items-center gap-1.5 rounded-xl px-4 py-2 text-xs font-bold transition ${
                        enrolled.has(course.id)
                          ? "bg-emerald-50 text-emerald-700 ring-1 ring-emerald-200"
                          : "bg-emerald-600 text-white shadow-sm hover:bg-emerald-700"
                      }`}
                    >
                      {enrolled.has(course.id)
                        ? <><Check className="h-3.5 w-3.5" /> في مساري</>
                        : "ابدأ التعلّم"}
                    </button>
                  </div>
                </div>
              </article>
            ))}
          </div>
        )}

        {/* ── Lab teaser ──────────────────────────────────── */}
        <aside className="lab-teaser mt-14 overflow-hidden rounded-3xl p-7 sm:p-10">
          <div className="relative z-10 max-w-2xl">
            <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-emerald-400/40 bg-emerald-500/15 px-3 py-1.5 text-xs font-black text-emerald-300">
              <Zap className="h-3.5 w-3.5" />
              مختبرات تفاعلية · قيد المراجعة الطبية
            </div>
            <h2 className="text-2xl font-black text-white sm:text-3xl">
              ستتعلم من الحالة،{" "}
              <span className="text-emerald-300">لا من المحاضرة وحدها.</span>
            </h2>
            <p className="mt-3 max-w-xl text-sm leading-7 text-white/70">
              يجري إعداد أول مختبر سريري تفاعلي ليُطلق فقط بعد اعتماد المحتوى وآليات الوصول الآمن.
            </p>
          </div>
          <div className="lab-orb lab-orb-one" />
          <div className="lab-orb lab-orb-two" />
        </aside>
      </section>
    </div>
  );
}
