import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { Menu, X, Stethoscope, Bell, ChevronDown } from "lucide-react";
import Button from "@/components/ui/Button";

const NAV_LINKS = [
  { to: "/doctors", label: "الأطباء" },
  { to: "/courses", label: "الدورات" },
  { to: "/library", label: "المكتبة" },
  { to: "/articles", label: "المقالات" },
  { to: "/consultations", label: "الاستشارات", comingSoon: true },
];

// TODO: Replace with real auth state from Supabase auth
const MOCK_USER = null as null | { name: string; role: string };

export default function Header() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const location = useLocation();

  function isActive(path: string) {
    return location.pathname.startsWith(path);
  }

  return (
    <header className="sticky top-0 z-50 border-b border-slate-100 bg-white/98 shadow-[0_1px_8px_rgba(11,74,95,.06)] backdrop-blur-sm" dir="rtl">
      <div className="mx-auto max-w-6xl px-4 sm:px-6">
        <div className="flex h-[4.25rem] items-center justify-between">

          {/* Logo */}
          <Link to="/" className="group flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary-600 shadow-md shadow-primary-600/25 transition-colors group-hover:bg-primary-700">
              <Stethoscope className="h-4.5 w-4.5 text-white" strokeWidth={2.2} />
            </div>
            <span className="text-xl font-black tracking-tight text-slate-900">
              ميدكونكت
            </span>
          </Link>

          {/* Desktop nav */}
          <nav className="hidden items-center gap-0.5 md:flex">
            {NAV_LINKS.map((link) => (
              <Link
                key={link.to}
                to={link.comingSoon ? "#" : link.to}
                className={`relative px-3.5 py-2 text-sm font-semibold rounded-xl transition-colors ${
                  isActive(link.to) && !link.comingSoon
                    ? "text-primary-700 bg-primary-50"
                    : "text-slate-600 hover:text-slate-900 hover:bg-slate-50"
                } ${link.comingSoon ? "opacity-70" : ""}`}
                onClick={link.comingSoon ? (e) => e.preventDefault() : undefined}
              >
                {link.label}
                {link.comingSoon && (
                  <span className="absolute -top-1 -end-1 rounded-full bg-coral-500 px-1.5 py-0.5 text-[9px] font-bold leading-none text-white">
                    قريبًا
                  </span>
                )}
              </Link>
            ))}
          </nav>

          {/* Auth area */}
          <div className="hidden items-center gap-2 md:flex">
            {MOCK_USER ? (
              <>
                <button className="relative rounded-xl p-2 text-slate-500 transition-colors hover:bg-slate-100 hover:text-slate-700">
                  <Bell className="h-5 w-5" />
                </button>
                <button className="flex items-center gap-2 rounded-xl px-3 py-1.5 transition-colors hover:bg-slate-50">
                  <div className="flex h-7 w-7 items-center justify-center rounded-full bg-primary-100 text-sm font-semibold text-primary-700">
                    {MOCK_USER.name[0]}
                  </div>
                  <span className="text-sm font-medium text-slate-700">{MOCK_USER.name}</span>
                  <ChevronDown className="h-4 w-4 text-slate-400" />
                </button>
              </>
            ) : (
              <>
                <Link to="/auth/login">
                  <Button variant="ghost" size="sm" className="font-semibold text-slate-600 hover:text-slate-900">
                    تسجيل الدخول
                  </Button>
                </Link>
                <Link to="/auth/signup">
                  <Button size="sm" className="rounded-xl shadow-md shadow-primary-600/20">
                    إنشاء حساب مجاني
                  </Button>
                </Link>
              </>
            )}
          </div>

          {/* Mobile toggle */}
          <button
            className="rounded-xl p-2 text-slate-600 transition-colors hover:bg-slate-100 md:hidden"
            onClick={() => setMobileOpen(!mobileOpen)}
            aria-label={mobileOpen ? "إغلاق القائمة" : "فتح القائمة"}
          >
            {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {/* Mobile nav */}
      {mobileOpen && (
        <div className="border-t border-slate-100 bg-white px-4 py-4 space-y-1 md:hidden">
          {NAV_LINKS.map((link) => (
            <Link
              key={link.to}
              to={link.comingSoon ? "#" : link.to}
              onClick={() => !link.comingSoon && setMobileOpen(false)}
              className={`flex items-center justify-between rounded-xl px-3.5 py-3 text-sm font-semibold transition-colors ${
                isActive(link.to) && !link.comingSoon
                  ? "bg-primary-50 text-primary-700"
                  : "text-slate-700 hover:bg-slate-50"
              } ${link.comingSoon ? "opacity-60" : ""}`}
            >
              {link.label}
              {link.comingSoon && (
                <span className="rounded-full bg-coral-500 px-2 py-0.5 text-[10px] font-bold text-white">
                  قريبًا
                </span>
              )}
            </Link>
          ))}
          <div className="mt-3 flex flex-col gap-2 border-t border-slate-100 pt-4">
            <Link to="/auth/login" onClick={() => setMobileOpen(false)}>
              <Button variant="outline" className="w-full justify-center">تسجيل الدخول</Button>
            </Link>
            <Link to="/auth/signup" onClick={() => setMobileOpen(false)}>
              <Button className="w-full justify-center">إنشاء حساب مجاني</Button>
            </Link>
          </div>
        </div>
      )}
    </header>
  );
}
