import Header from "./Header";
import Footer from "./Footer";
import StarField from "@/components/decorative/StarField";
import type { ReactNode } from "react";

export default function Layout({ children }: { children: ReactNode }) {
  return (
    <div className="site-shell min-h-screen flex flex-col bg-white">
      <StarField count={60} />
      <Header />
      <main className="flex-1 page-enter">{children}</main>
      <Footer />
    </div>
  );
}
