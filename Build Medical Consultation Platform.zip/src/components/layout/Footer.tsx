import { Link } from "react-router-dom";
import { Stethoscope, Heart, AlertTriangle } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-slate-900 text-slate-300 mt-auto" dir="rtl">
      {/* Top accent strip */}
      <div className="h-1 w-full bg-gradient-to-l from-primary-600 via-primary-400 to-transparent opacity-70" />

      <div className="mx-auto max-w-6xl px-4 sm:px-6 py-14">
        <div className="grid grid-cols-1 gap-10 sm:grid-cols-2 lg:grid-cols-4 lg:gap-12">

          {/* Brand */}
          <div className="sm:col-span-2 lg:col-span-1">
            <div className="flex items-center gap-2.5 mb-5">
              <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary-600 shadow-md shadow-primary-600/30">
                <Stethoscope className="h-4 w-4 text-white" strokeWidth={2.2} />
              </div>
              <span className="text-lg font-black text-white tracking-tight">ميدكونكت</span>
            </div>
            <p className="text-sm leading-7 text-slate-400 max-w-xs">
              منصة طبية موثوقة تربطك بأطباء متخصصين معتمدين للحصول على إجابات طبية في أي وقت.
            </p>
            <div className="mt-5 rounded-xl bg-slate-800 border border-slate-700/80 p-3.5">
              <p className="flex items-center gap-1.5 text-xs font-semibold text-amber-400">
                <AlertTriangle className="h-3.5 w-3.5" /> تنبيه هام
              </p>
              <p className="mt-1.5 text-xs leading-6 text-slate-400">
                هذه المنصة لأغراض استشارية فقط ولا تُغني عن الفحص الطبي المباشر.{" "}
                <Link to="/legal/disclaimer" className="text-primary-400 hover:text-primary-300 underline underline-offset-2">
                  اقرأ التنويه الكامل
                </Link>
              </p>
            </div>
          </div>

          {/* Services */}
          <div>
            <h3 className="mb-5 text-sm font-bold text-white">خدماتنا</h3>
            <ul className="space-y-3 text-sm">
              <li>
                <Link to="/consultations/new" className="text-slate-400 transition-colors hover:text-white">
                  استشارة طبية مجانية
                </Link>
              </li>
              <li>
                <Link to="/doctors" className="text-slate-400 transition-colors hover:text-white">
                  دليل الأطباء
                </Link>
              </li>
              <li>
                <Link to="/articles" className="text-slate-400 transition-colors hover:text-white">
                  مقالات صحية
                </Link>
              </li>
              <li>
                <Link to="/courses" className="text-slate-400 transition-colors hover:text-white">
                  الدورات التعليمية
                </Link>
              </li>
              <li>
                <Link to="/library" className="text-slate-400 transition-colors hover:text-white">
                  المكتبة الطبية
                </Link>
              </li>
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h3 className="mb-5 text-sm font-bold text-white">القانوني</h3>
            <ul className="space-y-3 text-sm">
              <li>
                <Link to="/legal/disclaimer" className="text-slate-400 transition-colors hover:text-white">
                  التنويه الطبي
                </Link>
              </li>
              <li>
                <Link to="/legal/terms" className="text-slate-400 transition-colors hover:text-white">
                  شروط الاستخدام
                </Link>
              </li>
              <li>
                <Link to="/legal/privacy" className="text-slate-400 transition-colors hover:text-white">
                  سياسة الخصوصية
                </Link>
              </li>
            </ul>
          </div>

          {/* Join as doctor */}
          <div>
            <h3 className="mb-5 text-sm font-bold text-white">للأطباء</h3>
            <p className="text-sm leading-7 text-slate-400 mb-4">
              طبيب مرخص؟ انضم لشبكتنا وساهم في تعزيز الوعي الصحي.
            </p>
            <Link
              to="/auth/signup?role=doctor"
              className="inline-flex items-center gap-1.5 rounded-xl border border-primary-500/40 bg-primary-600/10 px-4 py-2 text-sm font-semibold text-primary-400 transition hover:bg-primary-600/20 hover:text-primary-300"
            >
              سجّل كطبيب ←
            </Link>
          </div>
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t border-slate-800 pt-7 text-xs text-slate-500 sm:flex-row">
          <p>© {new Date().getFullYear()} ميدكونكت. جميع الحقوق محفوظة.</p>
          <p className="flex items-center gap-1.5">
            صُنع بـ <Heart className="h-3.5 w-3.5 fill-coral-500 text-coral-500" /> لخدمة المريض العربي
          </p>
        </div>
      </div>
    </footer>
  );
}
